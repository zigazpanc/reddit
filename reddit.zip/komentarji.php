<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Reddit page</title>
	<?php include('links.php'); ?>
</head>

<body>
	 
 <?php include('header.php'); ?>
 			
	  <?php include('koment.php'); ?>
	  

	</body>
</html>