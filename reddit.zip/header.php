<section class="nav-bar">
  <div class="nav-container">
    <div class="brand">
      <a href="home.php"><img src="imgs/logo_reddit.png"></a>
    </div>
    <nav>
      <div class="nav-mobile"><a id="nav-toggle" href="#!"><span></span></a></div>
      <ul class="nav-list">
       
        <li>
			
        </li>
        
        <li>
          <a href="#">Home</a>
	    <ul class="nav-dropdown">
            <li>
              <a href="display_subreddits.php">Subreddits</a>
            </li>
            <li>
              <a href="home.php">All</a>
            </li>
            <li>
              <a href="og.php">Trending</a>
            </li>
			</ul> 
		</li>
		<li>
          <a href="#">New</a>
	    <ul class="nav-dropdown">
            <li>
              <a href="new_post.php">Post</a>
            </li>
            <li>
              <a href="new_subreddit.php">Subreddit</a>
            </li>
			</ul> 
		</li>	
		<li>
          <a href="#">User</a>
          <ul class="nav-dropdown">
            <li>
              <a href="post_delete.php">My profile</a>
            </li>
            <li>
              <a href="user.php">User settings</a>
            </li>
			   <li>
              <a href="logout.php">Log out</a>
            </li>
          </ul>
        </li>
    </nav>
  </div>
</section>