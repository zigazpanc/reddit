<?php 
if(!isset($_SESSION['Logged'])){
    header("Location: login.php");
}
?>

<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Reddit page</title>
	<?php include('links.php'); ?>
</head>

<body>
	 
 <?php include('header.php'); ?>
 			
	  <?php include('post.php'); ?>
	  

	</body>
</html>